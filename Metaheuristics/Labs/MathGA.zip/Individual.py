"""
Author: Alejandro Arbelaez (Alejandro.Arbelaez@cit.ie)
Math example
file: Individual.py
"""



import random
import math

class Individual:
    def __init__(self, _size):
        """
        Parameters and general variables
        """
        self.fitness = 0
        self.genes   = []
        self.genSize = _size

        for i in range(0, self.genSize):
            self.genes.append( random.randint(0, 1))

    def getFitness(self):
        return self.fitness

    def flipGene(self, index):
        """
        Changing the truth value of a given variable
        """
        self.genes[index] = 1 - self.genes[index]

    def binaryToInt(self):
        """
        Computing int representation of the individual
        """
        result = 0
        index  = self.genSize - 1
        count  = 0
        while index >= 0:
            result += int(math.pow(2, count))* self.genes[count]
            count  += 1
            index  -= 1
        return result

    def toString(self):
        result = ""
        for gene_i in self.genes:
            result += str(gene_i)
        return result

    def computeFitness(self):
        """
        Current fitness value.
        Objective function: -(x^2/10) + 3*x (x --> current individual)
        """
        self.fitness = 0
        x = self.binaryToInt()
        self.fitness = -(x**2)/10.0 + 3.0*x


    def copy(self):
        """
        Cloning this object
        """
        ind = Individual(self.genSize)
        for i in range(0, self.genSize):
            ind.genes[i] = self.genes[i]
        return ind

