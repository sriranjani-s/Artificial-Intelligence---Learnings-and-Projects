
"""
Author: Alejandro Arbelaez (Alejandro.Arbelaez@cit.ie)
Monkey example
file: Example.py
"""

import random
from Individual import *


class GA:

    def __init__(self, _popSize, _genSize, _mutationRate, _maxIterations):
        """
        Parameters and general variables
        """
        self.population     = []
        self.matingPool     = []
        self.best           = None
        self.popSize        = _popSize
        self.genSize        = _genSize
        self.mutationRate   = _mutationRate
        self.maxIterations  = _maxIterations
        self.iteration      = 0
        self.initPopulation()

    def initPopulation(self):
        """
        Creating the initial population (random values)
        """
        for i in range(0, self.popSize):
            individual = Individual(self.genSize)
            individual.computeFitness()
            self.population.append(individual)
        self.best = self.population[0]

    def randomSelection(self):
        """
        Random (uniform) selection of two individuals
        """
        indA = self.matingPool[ random.randint(0, self.popSize-1) ]
        indB = self.matingPool[ random.randint(0, self.popSize-1) ]
        return [indA, indB]

    def crossover(self, indA, indB):
        """
        Executes a one point crossover and returns a new individual
        :param ind1: The first parent (or individual)
        :param ind2: The second parent (or individual)
        :returns: A new individual
        """
        child           = Individual(self.genSize)
        midPoint        = random.randint(0, self.genSize)

        for i in range(0, self.genSize):
            if( i > midPoint ):
                child.genes[i]  = indA.genes[i]
            else:
                child.genes[i]  = indB.genes[i]
        child.computeFitness()
        self.updateBest(child)
        return child

    def updateBest(self, candidate):
        """
        updating the best individual observed so far
        """
        if candidate.getFitness() > self.best.getFitness():
            self.best = candidate
            print ("Best: ", self.best.getFitness()," iterations: ",self.iteration)

    def newGeneration(self):
        """
        Creating a new generation
        1. Selection
        2. Crossover
        3. Mutation
        """
        for i in range(0, len(self.population)):
            #matingPool = self.selection()
            #[ind1, ind2] = self.randomSelection()
            [ind1, ind2] = self.randomSelection()
            child = self.crossover(ind1, ind2)
            self.mutation(child)
            self.population[i] = child

    def mutation(self, candidate):
        """
        Mutate and individual by changing its truth value with certain probability (i.e., mutation rate)
        :param ind: An individual
        :return: A new individual
        """
        for gene_index in range(0, self.genSize):
            if(random.random() < self.mutationRate):
                #candidate.genes[gene_index] = 1 - candidate.genes[gene_index]
                candidate.flipGene(gene_index)
        candidate.computeFitness()
        self.updateBest(candidate)

    def printPopulation(self):
        for ind_i in self.population:
            print (ind_i.genes, ind_i.getFitness())

    def updateMatingPool(self):
        """
        Updating the mating pool before creating a new generation
        """
        self.matingPool = []
        for ind_i in self.population:
            self.matingPool.append( ind_i.copy() )

    def GAStep(self):
        """
        One step in the GA main algorithm
        1. Computing Fitness for each candidate in the population
        2. Updating mating pool with current population
        3. Creating a new Generation
        """
        for ind_i in self.population:
            ind_i.computeFitness()
        self.updateMatingPool()
        self.newGeneration()

    def search(self):
        """
        General search template.
        Iterates for a given number of iterations
        """

        self.iteration = 0
        while self.iteration < self.maxIterations:
            self.GAStep()
            self.iteration += 1
        print ("Total iterations: ", self.iteration)
        print ("Best solution: ",self.best.getFitness())

ga = GA(10, 5, 0.1, 10000)
ga.search()


