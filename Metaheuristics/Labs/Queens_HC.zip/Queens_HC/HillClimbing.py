
import random
from Queens import *
import matplotlib.pyplot as plt
import sys

random.seed(12345)

class HillClimbing:
    def __init__(self, _size, _maxIterations, _maxRestarts):
        self.bCost = 0
        self.maxIterations = _maxIterations
        self.maxRestarts = _maxRestarts
        self.gIteration = 0
        self.nRestart = 0
        self.iteration = 0
        self.size = _size
        self.q = Queens(self.size)
        self.bCost = -1
        self.cHistory = []
        self.cBHistory = []
        self.iHistory = []

    def solveMaxMin(self):
        candidate_sol = self.q.generateRandomState(self.size)
        self.bCost = self.q.getHeuristicCost(candidate_sol)
        self.iteration = -1

        while self.iteration < self.maxIterations and self.bCost > 0:
            self.gIteration += 1
            self.iteration += 1
            self.cBHistory.append(self.bCost)
            self.cHistory.append (self.q.getHeuristicCost(candidate_sol))
            self.iHistory.append(self.gIteration)

            max_candidate = []
            max_cost = -1
            # Find queen involved in max conflicts
            for cand_i in range(0, self.size):
                cost_i = self.q.getHeuristicCostQueen(candidate_sol, cand_i)
                if max_cost < cost_i:
                    max_cost = cost_i
                    max_candidate = [cand_i]
                elif max_cost == cost_i:
                    # Ties
                    max_candidate.append(cand_i)

            if max_cost == -1:
                break
            candidate = max_candidate[ random.randint(0, len(max_candidate)-1) ]
            old_val = candidate_sol[candidate]

            ##best move for the selected queen
            min_cost = max_cost
            best_pos = []

            for pos_i in range(0, self.size):
                if pos_i == old_val:
                    # Neighbor must be different to current
                    continue
                candidate_sol[candidate] = pos_i
                cost_i = self.q.getHeuristicCostQueen(candidate_sol, candidate)
                if min_cost > cost_i:
                    min_cost = cost_i
                    best_pos = [pos_i]
                elif min_cost == cost_i:
                    # Note this will allow sideways moves
                    best_pos.append(pos_i)
            if best_pos:
                # Some non-worsening move found
                candidate_sol[candidate] = best_pos[ random.randint(0, len(best_pos)-1) ]
                cost_i = self.q.getHeuristicCost(candidate_sol)
            else:
                # Put back previous sol if no improving solution
                candidate_sol[candidate]=old_val
            if self.bCost > cost_i:
                self.bCost = cost_i
        return (candidate_sol, self.bCost)
    

    def solveLocalOpt(self):
        candidate_sol = self.q.generateRandomState(self.size)
        self.bCost = self.q.getHeuristicCost(candidate_sol)
        self.iteration = -1
        iterchecked= [0 for i in range(self.size)]

        while self.iteration < self.maxIterations and self.bCost > 0:
            self.gIteration += 1
            self.iteration += 1
            self.cBHistory.append(self.bCost)
            self.cHistory.append (self.q.getHeuristicCost(candidate_sol))
            self.iHistory.append(self.gIteration)

            max_candidate = []
            max_cost = -1
            # Find queen involve in max conflicts
            for cand_i in range(0, self.size):
                if iterchecked[cand_i]:
                    # Only check candidates that haven't been tested for local minima
                    continue
                cost_i = self.q.getHeuristicCostQueen(candidate_sol, cand_i)
                if max_cost < cost_i:
                    max_cost = cost_i
                    max_candidate = [cand_i]
                elif max_cost == cost_i:
                    # Ties
                    max_candidate.append(cand_i)

            if not max_candidate:
                break
            candidate = max_candidate[ random.randint(0, len(max_candidate)-1) ]
            old_val = candidate_sol[candidate]
            iterchecked[candidate] = 0

            ##best move for the selected queen
            min_cost = max_cost
            best_pos = []

            for pos_i in range(0, self.size):
                if pos_i == old_val:
                    # Neighbor must be different to current
                    continue
                candidate_sol[candidate] = pos_i
                cost_i = self.q.getHeuristicCostQueen(candidate_sol, candidate)
                if min_cost > cost_i:
                    min_cost = cost_i
                    best_pos = [pos_i]
                elif min_cost == cost_i:
                    best_pos.append(pos_i)
            if best_pos:
                candidate_sol[candidate] = best_pos[ random.randint(0, len(best_pos)-1) ]
                cost_i = self.q.getHeuristicCost(candidate_sol)
                if self.bCost > cost_i:
                    self.bCost = cost_i
                    iterchecked= [0 for i in range(self.size)]
                else:
                    candidate_sol[candidate]=old_val
#                print ("Iter: ", self.iteration, self.gIteration, "bCost: ", self.bCost)
        return (candidate_sol, self.bCost)

    ##First improvement
    def solveFirstImp(self):
        candidate_sol = self.q.generateRandomState(self.size)
        self.bCost = self.q.getHeuristicCost(candidate_sol)
        self.iteration = -1

        while self.iteration < self.maxIterations and self.bCost > 0:
            self.iteration += 1
            self.gIteration += 1
            self.cBHistory.append(self.bCost)
            self.cHistory.append (self.q.getHeuristicCost(candidate_sol))
            self.iHistory.append(self.gIteration)
            flag = True
            col = 0
            while col < self.size and flag:
                for row in range(0, self.size):
                    if row == candidate_sol[col]:
                        continue
                    ##copying candidate solution
                    rc = []
                    for i in candidate_sol:
                        rc.append(i)

                    rc[col] = row
                    cost = self.q.getHeuristicCost(rc)
                    if self.bCost > cost:
                        candidate_sol[col] = row
                        self.bCost = cost
#                        print ("Iter: ", self.gIteration, "bCost: ", self.bCost)
                        flag = False
                        break
                col += 1
            cost_i = self.q.getHeuristicCost(candidate_sol)
            return (candidate_sol, self.bCost)
    
    def solveWithRestarts(self, solve, maxR):
        res = solve()
        self.nRestart = 0
        print ("Restart: ",self.nRestart, "Cost: ",res[1], "Iter: ",self.iteration)
        while self.nRestart < maxR and res[1] > 0:
            self.nRestart +=1
            res = solve()
            print ("Restart: ",self.nRestart, "Cost: ",res[1], "Iter: ",self.iteration, self.gIteration)
        print ("Restart: ",self.nRestart, "Cost: ",res[1], "Iter: ",self.iteration, self.gIteration)
        return res

#print ("Size: ", sys.argv[1])
#print ("maxSteps: ",sys.argv[2])
#print ("maxRes: ",sys.argv[3])
        
#hc = HillClimbing(int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]))
for i in range(10):
    hc = HillClimbing(64,100,40)
#    sol = hc.solveWithRestarts(hc.solveMaxMin, hc.maxRestarts)
    sol = hc.solveWithRestarts(hc.solveLocalOpt, hc.maxRestarts)
#    print ("Sol cost: ", sol)

#sol = hc.solveWithRestarts(hc.solve, hc.maxRestarts)

hc.q.printSolution(sol[0])
print ("Sol cost: ", sol)

plt.plot(hc.iHistory, hc.cHistory, '-')
plt.show()
